/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyectoaplicaciones;

import vista.login;

/**
 *
 * @author WindowsPC
 */
public class ProyectoAplicaciones {

    public static void main(String[] args) {
        login pension =new login();
        pension.setVisible(true);
    }
}
