/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package vista;

import java.awt.Color;
import java.awt.Font;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import javax.swing.Timer;

/**
 *
 * @author WindowsPC
 */
public class Registrarse extends javax.swing.JPanel {

    /**
     * Creates new form Registrarse
     */
    public Registrarse() {
        initComponents();
    inicializarComponentes();
        asignarAccionesBotones();
        configurarValidacionesEnTiempoReal();
    }

    private void inicializarComponentes() {
        configurarLabelsError();
        limpiarMensajesError();
    }

    private void configurarLabelsError() {
        lblErrorCorreo.setForeground(Color.RED);
        lblErrorNombre.setForeground(Color.RED);
        lblErrorContraseña.setForeground(Color.RED);
        lblErrorConfirmar.setForeground(Color.RED);
        
        Font errorFont = new Font(lblErrorCorreo.getFont().getName(), Font.PLAIN, 10);
        lblErrorCorreo.setFont(errorFont);
        lblErrorNombre.setFont(errorFont);
        lblErrorContraseña.setFont(errorFont);
        lblErrorConfirmar.setFont(errorFont);
    }

    private void asignarAccionesBotones() {
        btnRegistrarse.addActionListener(e -> botonRegistrarsePresionado());
        btnVolver.addActionListener(e -> botonVolverPresionado());
        btnCancelar.addActionListener(e -> botonCancelarPresionado());
    }

    private void configurarValidacionesEnTiempoReal() {
        txtCorreo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                validarCorreoElectronico();
            }
        });

        txtUsuario.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                validarNombreUsuario();
            }
        });

        txtContraseña.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                validarContraseña();
            }
        });

        txtConfirmarContra.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                validarConfirmacionContraseña();
            }
        });
    }

    // VALIDACIONES
    private final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    private final Pattern NOMBRE_PATTERN = Pattern.compile("^[a-zA-Z0-9_]{3,20}$");

    private boolean validarCorreoElectronico() {
        String correo = txtCorreo.getText().trim();
        
        if (correo.isEmpty()) {
            lblErrorCorreo.setText("El correo electrónico es obligatorio");
            return false;
        }
        
        if (!EMAIL_PATTERN.matcher(correo).matches()) {
            lblErrorCorreo.setText("Formato de correo electrónico inválido");
            return false;
        }
        
        lblErrorCorreo.setText("");
        return true;
    }

    private boolean validarNombreUsuario() {
        String usuario = txtUsuario.getText().trim();
        
        if (usuario.isEmpty()) {
            lblErrorNombre.setText("El nombre de usuario es obligatorio");
            return false;
        }
        
        if (usuario.length() < 3) {
            lblErrorNombre.setText("Mínimo 3 caracteres");
            return false;
        }
        
        if (usuario.length() > 20) {
            lblErrorNombre.setText("Máximo 20 caracteres");
            return false;
        }
        
        if (!NOMBRE_PATTERN.matcher(usuario).matches()) {
            lblErrorNombre.setText("Solo letras, números y guiones bajos");
            return false;
        }
        
        lblErrorNombre.setText("");
        return true;
    }

    private boolean validarContraseña() {
        String contraseña = txtContraseña.getText();
        
        if (contraseña.isEmpty()) {
            lblErrorContraseña.setText("La contraseña es obligatoria");
            return false;
        }
        
        if (contraseña.length() < 8) {
            lblErrorContraseña.setText("Mínimo 8 caracteres");
            return false;
        }
        
        boolean tieneMayuscula = false;
        boolean tieneMinuscula = false;
        boolean tieneNumero = false;
        
        for (char c : contraseña.toCharArray()) {
            if (Character.isUpperCase(c)) tieneMayuscula = true;
            if (Character.isLowerCase(c)) tieneMinuscula = true;
            if (Character.isDigit(c)) tieneNumero = true;
        }
        
        if (!tieneMayuscula) {
            lblErrorContraseña.setText("Debe tener al menos una mayúscula");
            return false;
        }
        
        if (!tieneMinuscula) {
            lblErrorContraseña.setText("Debe tener al menos una minúscula");
            return false;
        }
        
        if (!tieneNumero) {
            lblErrorContraseña.setText("Debe tener al menos un número");
            return false;
        }
        
        lblErrorContraseña.setText("");
        return true;
    }

    private boolean validarConfirmacionContraseña() {
        String contraseña = txtContraseña.getText();
        String confirmacion = txtConfirmarContra.getText();
        
        if (confirmacion.isEmpty()) {
            lblErrorConfirmar.setText("Confirme su contraseña");
            return false;
        }
        
        if (!contraseña.equals(confirmacion)) {
            lblErrorConfirmar.setText("Las contraseñas no coinciden");
            return false;
        }
        
        lblErrorConfirmar.setText("");
        return true;
    }

    private boolean validarFormularioCompleto() {
        boolean correoValido = validarCorreoElectronico();
        boolean usuarioValido = validarNombreUsuario();
        boolean contraseñaValida = validarContraseña();
        boolean confirmacionValida = validarConfirmacionContraseña();
        
        return correoValido && usuarioValido && contraseñaValida && confirmacionValida;
    }

    // ACCIONES DE BOTONES
    private void botonRegistrarsePresionado() {
        if (validarFormularioCompleto()) {
            btnRegistrarse.setEnabled(false);
            btnRegistrarse.setText("Registrando...");
            
            Timer timer = new Timer(2000, e -> {
                boolean registroExitoso = registrarUsuarioEnBD();
                
                if (registroExitoso) {
                    JOptionPane.showMessageDialog(this,
                        "¡Registro exitoso! Bienvenido " + txtUsuario.getText(),
                        "Registro Completado",
                        JOptionPane.INFORMATION_MESSAGE);
                    limpiarFormulario();
                    // Notificar al contenedor principal para cambiar al panel de login
                    notificarRegistroExitoso();
                } else {
                    JOptionPane.showMessageDialog(this,
                        "Error en el registro. El usuario podría existir.",
                        "Error de Registro",
                        JOptionPane.ERROR_MESSAGE);
                }
                
                btnRegistrarse.setEnabled(true);
                btnRegistrarse.setText("Registrarse");
            });
            timer.setRepeats(false);
            timer.start();
        } else {
            JOptionPane.showMessageDialog(this,
                "Por favor, corrija los errores en el formulario",
                "Errores de Validación",
                JOptionPane.WARNING_MESSAGE);
        }
    }

    private void botonVolverPresionado() {
        int respuesta = JOptionPane.showConfirmDialog(this,
            "¿Volver al login? Los datos no guardados se perderán.",
            "Confirmar",
            JOptionPane.YES_NO_OPTION);
        
        if (respuesta == JOptionPane.YES_OPTION) {
            // Notificar al contenedor principal para volver al login
            notificarVolverALogin();
        }
    }

    private void botonCancelarPresionado() {
        int respuesta = JOptionPane.showConfirmDialog(this,
            "¿Está seguro de que desea cancelar el registro?",
            "Confirmar Cancelación",
            JOptionPane.YES_NO_OPTION);
        
        if (respuesta == JOptionPane.YES_OPTION) {
            limpiarFormulario();
            // Notificar al contenedor principal para cerrar o volver
            notificarCancelarRegistro();
        }
    }

    // MÉTODOS AUXILIARES
    private boolean registrarUsuarioEnBD() {
        String usuario = txtUsuario.getText().trim();
        String correo = txtCorreo.getText().trim();
        String contraseña = txtContraseña.getText();
        
        System.out.println("Registrando usuario:");
        System.out.println("Usuario: " + usuario);
        System.out.println("Correo: " + correo);
        System.out.println("Contraseña: " + contraseña);
        
        // Aquí iría tu lógica real de base de datos
        return true;
    }

    void limpiarFormulario() {
        txtCorreo.setText("");
        txtUsuario.setText("");
        txtContraseña.setText("");
        txtConfirmarContra.setText("");
        limpiarMensajesError();
    }

    private void limpiarMensajesError() {
        lblErrorCorreo.setText("");
        lblErrorNombre.setText("");
        lblErrorContraseña.setText("");
        lblErrorConfirmar.setText("");
    }

    // MÉTODOS PARA COMUNICACIÓN CON EL CONTENEDOR PRINCIPAL
    public interface RegistroListener {
        void onRegistroExitoso();
        void onVolverALogin();
        void onCancelarRegistro();
    }
    
    private RegistroListener listener;
    
    public void setRegistroListener(RegistroListener listener) {
        this.listener = listener;
    }
    
    private void notificarRegistroExitoso() {
        if (listener != null) {
            listener.onRegistroExitoso();
        }
    }
    
    private void notificarVolverALogin() {
        if (listener != null) {
            listener.onVolverALogin();
        }
    }
    
    private void notificarCancelarRegistro() {
        if (listener != null) {
            listener.onCancelarRegistro();
        }
    }    
    
    // Agregar estos métodos públicos para mejor control
  
    
    public void focusEnPrimerCampo() {
        txtCorreo.requestFocusInWindow();
    }
    
    // Método para ser llamado desde el JFrame principal
    public void prepararParaMostrar() {
        limpiarFormulario();
        focusEnPrimerCampo();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        REGISTRARSE = new javax.swing.JPanel();
        lblTiRe = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txtCorreo = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtUsuario = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtContraseña = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtConfirmarContra = new javax.swing.JTextField();
        lblErrorConfirmar = new javax.swing.JLabel();
        lblErrorContraseña = new javax.swing.JLabel();
        lblErrorNombre = new javax.swing.JLabel();
        lblErrorCorreo = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btnRegistrarse = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();

        lblTiRe.setText("REGISTRARSE");

        jLabel1.setText("ingrese su correo:");

        jLabel2.setText("ingrese su nombre de usuario:");

        jLabel3.setText("ingrese su contraseña:");

        jLabel4.setText("confirmar su contraseña:");

        javax.swing.GroupLayout REGISTRARSELayout = new javax.swing.GroupLayout(REGISTRARSE);
        REGISTRARSE.setLayout(REGISTRARSELayout);
        REGISTRARSELayout.setHorizontalGroup(
            REGISTRARSELayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(REGISTRARSELayout.createSequentialGroup()
                .addGroup(REGISTRARSELayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(REGISTRARSELayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, REGISTRARSELayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(REGISTRARSELayout.createSequentialGroup()
                                .addGap(167, 167, 167)
                                .addComponent(lblTiRe))
                            .addGroup(REGISTRARSELayout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(REGISTRARSELayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addGroup(REGISTRARSELayout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addGroup(REGISTRARSELayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(txtCorreo, javax.swing.GroupLayout.DEFAULT_SIZE, 356, Short.MAX_VALUE)
                                            .addComponent(lblErrorCorreo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
                        .addGroup(REGISTRARSELayout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(jLabel3))
                        .addGroup(REGISTRARSELayout.createSequentialGroup()
                            .addContainerGap()
                            .addGroup(REGISTRARSELayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel4)
                                .addGroup(REGISTRARSELayout.createSequentialGroup()
                                    .addGap(6, 6, 6)
                                    .addGroup(REGISTRARSELayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtConfirmarContra, javax.swing.GroupLayout.DEFAULT_SIZE, 356, Short.MAX_VALUE)
                                        .addComponent(lblErrorConfirmar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                        .addGroup(REGISTRARSELayout.createSequentialGroup()
                            .addGap(12, 12, 12)
                            .addGroup(REGISTRARSELayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtContraseña, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(lblErrorContraseña, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, REGISTRARSELayout.createSequentialGroup()
                            .addContainerGap()
                            .addGroup(REGISTRARSELayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(lblErrorNombre, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, 356, Short.MAX_VALUE))))
                    .addComponent(jLabel2))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        REGISTRARSELayout.setVerticalGroup(
            REGISTRARSELayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(REGISTRARSELayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTiRe)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblErrorCorreo, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblErrorNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblErrorContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtConfirmarContra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblErrorConfirmar, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        btnRegistrarse.setText("Registrase");

        btnVolver.setText("volver");

        btnCancelar.setText("Cancelar");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(124, 124, 124)
                .addComponent(btnRegistrarse)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnVolver)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnCancelar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 10, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRegistrarse)
                    .addComponent(btnVolver)
                    .addComponent(btnCancelar)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(REGISTRARSE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(REGISTRARSE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel REGISTRARSE;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnRegistrarse;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lblErrorConfirmar;
    private javax.swing.JLabel lblErrorContraseña;
    private javax.swing.JLabel lblErrorCorreo;
    private javax.swing.JLabel lblErrorNombre;
    private javax.swing.JLabel lblTiRe;
    private javax.swing.JTextField txtConfirmarContra;
    private javax.swing.JTextField txtContraseña;
    private javax.swing.JTextField txtCorreo;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables
}
