/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;


/**
 *
 * @author WindowsPC
 */
public class login extends javax.swing.JFrame {
String nombre;
String contraseña;
private CardLayout cardLayout;
private JPanel cardPanel;
    private Registrarse registroPanel;

/**
 * Creates new form login
 */
public login() {
    initComponents();
    formulario();
    inicializarLabels();
    asignarFuncionesBotones(); // Nuevo método para asignar funciones
}

private void formulario(){
    this.setTitle("LOGIN");
    this.setLocationRelativeTo(null);
    this.setVisible(true);
    this.setSize(new Dimension (420, 390));
    this.setResizable(false);
    this.getContentPane().setBackground(Color.WHITE);
    this.panelIngreso.setBackground(Color.WHITE);
    this.panelSalir.setBackground(Color.WHITE);
}

private void inicializarLabels() {
    if (lblErrorUsuario == null) {
        lblErrorUsuario = new JLabel("");
        lblErrorUsuario.setForeground(Color.RED);
    }
    if (lblErrorContra == null) {
        lblErrorContra = new JLabel("");
        lblErrorContra.setForeground(Color.RED);
    }
    if (lblIngresando == null) {
        lblIngresando = new JLabel("");
        lblIngresando.setForeground(Color.BLUE);
    }
}

// MÉTODO PARA ASIGNAR FUNCIONES A LOS BOTONES
private void asignarFuncionesBotones() {
    // Botón Iniciar Sesión
    if (btnIniciar != null) {
        btnIniciar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                botonIniciarSesionPresionado();
            }
        });
    }
    
    // Botón Registrarse
    if (btnRegistrarse != null) {
        btnRegistrarse.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                botonRegistrarsePresionado();
            }
        });
    }
    
    // Botón Salir
    if (btnSalir != null) {
        btnSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                botonSalirPresionado();
            }
        });
    }
    
    // También puedes asignar eventos a los campos de texto (opcional)
    if (txtUsuario != null) {
        txtUsuario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Al presionar Enter en el campo usuario, pasar al campo contraseña
                txtContraseña.requestFocus();
            }
        });
    }
    
    if (txtContraseña != null) {
        txtContraseña.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Al presionar Enter en el campo contraseña, iniciar sesión
                botonIniciarSesionPresionado();
            }
        });
    }
}

// FUNCIÓN PARA EL BOTÓN INICIAR SESIÓN
private void botonIniciarSesionPresionado() {
    System.out.println("Botón Iniciar Sesión presionado");
    validarVacios();
    
    // Si la validación fue exitosa, proceder con el login
    if (camposValidos()) {
        realizarLogin();
    }
}

// FUNCIÓN PARA EL BOTÓN REGISTRARSE
private void botonRegistrarsePresionado() {
    System.out.println("Botón Registrarse presionado");
    
    // Limpiar mensajes previos
    limpiarMensajes();
    
    // Aquí puedes abrir una ventana de registro o cambiar a un panel de registro
    JOptionPane.showMessageDialog(this, 
        "Función de registro - Aquí iría el formulario de registro", 
        "Registro", 
        JOptionPane.INFORMATION_MESSAGE);
    
    // Ejemplo: cambiar a panel de registro si tienes CardLayout
    // cardLayout.show(cardPanel, "registro");
}

// FUNCIÓN PARA EL BOTÓN SALIR
private void botonSalirPresionado() {
    System.out.println("Botón Salir presionado");
    
    int confirmacion = JOptionPane.showConfirmDialog(
        this, 
        "¿Estás seguro de que quieres salir?", 
        "Confirmar salida", 
        JOptionPane.YES_NO_OPTION,
        JOptionPane.QUESTION_MESSAGE
    );
    
    if (confirmacion == JOptionPane.YES_OPTION) {
        System.exit(0); // Cerrar la aplicación
    }
}

// MÉTODO PARA VALIDAR SI LOS CAMPOS SON VÁLIDOS
private boolean camposValidos() {
    String contraseñaIng = txtContraseña.getText();
    String UsuarioN = txtUsuario.getText();
    boolean validos = true;
    
    limpiarMensajes();
    
    if (UsuarioN == null || UsuarioN.trim().isEmpty()){
        lblErrorUsuario.setText("El usuario no puede estar vacío");
        txtUsuario.requestFocus(); // Enfocar el campo vacío
        validos = false;
    }
    
    if (contraseñaIng == null || contraseñaIng.trim().isEmpty()){
        lblErrorContra.setText("La contraseña no puede estar vacía");
        if (validos) { // Solo enfocar si el usuario ya está lleno
            txtContraseña.requestFocus();
        }
        validos = false;
    }
    
    return validos;
}

// MÉTODO MEJORADO DE VALIDAR VACÍOS
void validarVacios() {
    // Este método ahora solo muestra mensajes, la lógica de validación está en camposValidos()
    camposValidos();
}

// MÉTODO PARA REALIZAR EL LOGIN
private void realizarLogin() {
    String usuario = txtUsuario.getText().trim();
    String password = txtContraseña.getText();
    
    lblIngresando.setText("Ingresando... espere un momento");
    
    // Simular proceso de login (aquí iría tu conexión a base de datos)
    Timer timer = new Timer(2000, new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Aquí va tu lógica de autenticación real
            if (autenticarUsuario(usuario, password)) {
                JOptionPane.showMessageDialog(login.this, 
                    "¡Login exitoso! Bienvenido " + usuario, 
                    "Éxito", 
                    JOptionPane.INFORMATION_MESSAGE);
                // Aquí puedes abrir la ventana principal
                // new VentanaPrincipal().setVisible(true);
                // dispose(); // Cerrar ventana de login
            } else {
                JOptionPane.showMessageDialog(login.this, 
                    "Usuario o contraseña incorrectos", 
                    "Error de login", 
                    JOptionPane.ERROR_MESSAGE);
                limpiarMensajes();
                txtContraseña.setText("");
                txtContraseña.requestFocus();
            }
        }
    });
    timer.setRepeats(false);
    timer.start();
}

// MÉTODO DE AUTENTICACIÓN (SIMULADO - REEMPLAZA CON TU LÓGICA REAL)
private boolean autenticarUsuario(String usuario, String password) {
    // Ejemplo simple - reemplaza con tu lógica de base de datos
    return "admin".equals(usuario) && "1234".equals(password);
}

private void limpiarMensajes() {
    if (lblErrorUsuario != null) {
        lblErrorUsuario.setText("");
    }
    if (lblErrorContra != null) {
        lblErrorContra.setText("");
    }
    if (lblIngresando != null) {
        lblIngresando.setText("");
    }
}

private void valIniciales(){
    this.panelIngreso.setVisible(true);
    this.panelSalir.setVisible(true);
    this.btnIniciar.setEnabled(true);
    this.btnRegistrarse.setEnabled(true);
    this.btnSalir.setEnabled(true);
    limpiarMensajes();
    this.revalidate();
    this.repaint();
}

 private void inicializarCardLayout() {
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);
        
        // Crear los paneles
        registroPanel = new Registrarse();
        
        // Configurar el listener para el panel de registro
        registroPanel.setRegistroListener(new Registrarse.RegistroListener() {
            @Override
            public void onRegistroExitoso() {
                // Volver al login después de registro exitoso
                cardLayout.show(cardPanel, "login");
            }
            
            @Override
            public void onVolverALogin() {
                // Volver al panel de login
                cardLayout.show(cardPanel, "login");
            }
            
            @Override
            public void onCancelarRegistro() {
                // Volver al panel de login
                cardLayout.show(cardPanel, "login");
            }
        });
        
        // Agregar paneles al cardPanel
        cardPanel.add(registroPanel, "registro");
        
        // Establecer cardPanel como contenido principal
        this.setContentPane(cardPanel);
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu1 = new javax.swing.JMenu();
        panelIngreso = new javax.swing.JPanel();
        lblTtiuloLogin = new javax.swing.JLabel();
        lblSubTitulo = new javax.swing.JLabel();
        lblUsuario = new javax.swing.JLabel();
        txtUsuario = new javax.swing.JTextField();
        lblContraseña = new javax.swing.JLabel();
        txtContraseña = new javax.swing.JTextField();
        btnIniciar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btnRegistrarse = new javax.swing.JToggleButton();
        lblErrorUsuario = new javax.swing.JLabel();
        lblErrorContra = new javax.swing.JLabel();
        lblIngresando = new javax.swing.JLabel();
        panelSalir = new javax.swing.JPanel();
        btnSalir = new javax.swing.JButton();

        jMenu1.setText("jMenu1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblTtiuloLogin.setText("Iniciar Sesion");
        lblTtiuloLogin.setToolTipText("Arial");

        lblSubTitulo.setText("Ingresa tus Credenciales para acceder");

        lblUsuario.setText("Usuario");

        txtUsuario.setToolTipText("");

        lblContraseña.setText("Contraseña");

        txtContraseña.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtContraseñaActionPerformed(evt);
            }
        });

        btnIniciar.setBackground(new java.awt.Color(0, 0, 0));
        btnIniciar.setForeground(new java.awt.Color(255, 255, 255));
        btnIniciar.setText("Iniciar Sesion");
        btnIniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIniciarActionPerformed(evt);
            }
        });

        jLabel1.setText("¿No tienes una cuenta?");

        btnRegistrarse.setText("Registrate");
        btnRegistrarse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistrarseActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelIngresoLayout = new javax.swing.GroupLayout(panelIngreso);
        panelIngreso.setLayout(panelIngresoLayout);
        panelIngresoLayout.setHorizontalGroup(
            panelIngresoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelIngresoLayout.createSequentialGroup()
                .addGroup(panelIngresoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelIngresoLayout.createSequentialGroup()
                        .addGap(78, 78, 78)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnRegistrarse))
                    .addGroup(panelIngresoLayout.createSequentialGroup()
                        .addGap(57, 57, 57)
                        .addComponent(btnIniciar, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelIngresoLayout.createSequentialGroup()
                        .addGap(120, 120, 120)
                        .addComponent(lblIngresando, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelIngresoLayout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(panelIngresoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblUsuario)
                            .addComponent(lblContraseña)
                            .addComponent(txtUsuario)
                            .addComponent(lblErrorUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblErrorContra, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtContraseña, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE))))
                .addContainerGap(11, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelIngresoLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(panelIngresoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelIngresoLayout.createSequentialGroup()
                        .addComponent(lblSubTitulo)
                        .addGap(93, 93, 93))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelIngresoLayout.createSequentialGroup()
                        .addComponent(lblTtiuloLogin)
                        .addGap(157, 157, 157))))
        );
        panelIngresoLayout.setVerticalGroup(
            panelIngresoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelIngresoLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(lblTtiuloLogin)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblSubTitulo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblUsuario)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4)
                .addComponent(lblErrorUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblContraseña)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblErrorContra, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnIniciar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelIngresoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(btnRegistrarse))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblIngresando, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        btnSalir.setText("cancelar");

        javax.swing.GroupLayout panelSalirLayout = new javax.swing.GroupLayout(panelSalir);
        panelSalir.setLayout(panelSalirLayout);
        panelSalirLayout.setHorizontalGroup(
            panelSalirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelSalirLayout.createSequentialGroup()
                .addContainerGap(288, Short.MAX_VALUE)
                .addComponent(btnSalir)
                .addGap(18, 18, 18))
        );
        panelSalirLayout.setVerticalGroup(
            panelSalirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelSalirLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnSalir)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(panelIngreso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(panelSalir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelIngreso, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelSalir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtContraseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtContraseñaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtContraseñaActionPerformed

    private void btnIniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIniciarActionPerformed
        // TODO add your handling code here:
        validarVacios();
    }//GEN-LAST:event_btnIniciarActionPerformed

    private void btnRegistrarseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarseActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_btnRegistrarseActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnIniciar;
    private javax.swing.JToggleButton btnRegistrarse;
    private javax.swing.JButton btnSalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JLabel lblContraseña;
    private javax.swing.JLabel lblErrorContra;
    private javax.swing.JLabel lblErrorUsuario;
    private javax.swing.JLabel lblIngresando;
    private javax.swing.JLabel lblSubTitulo;
    private javax.swing.JLabel lblTtiuloLogin;
    private javax.swing.JLabel lblUsuario;
    private javax.swing.JPanel panelIngreso;
    private javax.swing.JPanel panelSalir;
    private javax.swing.JTextField txtContraseña;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables
}
