/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package modulos.AdminDetalles;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import modulos.usuario.LoginView;
import vista.DashboardAdminView;

/**
 *
 * @author WindowsPC
 */
public class AdminMonitorView extends javax.swing.JFrame {
private DefaultTableModel modeloAnimo, modeloPublicaciones, modeloUsuarios;
    /**
     * Creates new form AdminMonitorView
     */
    public AdminMonitorView() {
        inicializar();
    }
    
    private void inicializar() {
        setTitle("Monitoreo del Sistema - StudyMind");
        setSize(950, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(245, 247, 250));
        setLayout(null);

        JLabel lblTitulo = new JLabel("Panel de Monitoreo del Administrador", JLabel.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitulo.setForeground(new Color(52, 73, 94));
        lblTitulo.setBounds(0, 15, 950, 40);
        add(lblTitulo);

        Pestañas = new JTabbedPane();
        Pestañas.setFont(new Font("Segoe UI", Font.BOLD, 14));
        Pestañas.setBounds(40, 70, 860, 400);
        add(Pestañas);

        // =========================
        // 🟢 TAB 1: Estados de Ánimo
        // =========================
        modeloAnimo = new DefaultTableModel(
                new Object[]{"ID", "Usuario", "Ánimo", "Comentario", "Fecha"}, 0);
        modeloAnimo.addRow(new Object[]{"A001", "Juan Pérez", "Feliz", "Buen día de estudio", "2025-10-18"});
        modeloAnimo.addRow(new Object[]{"A002", "Ana Torres", "Estresada", "Mucho trabajo", "2025-10-17"});

        EstadosAnimo = new JTable(modeloAnimo);
        EstadosAnimo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        EstadosAnimo.setRowHeight(25);
        EstadosAnimo.setSelectionBackground(new Color(52, 152, 219));
        EstadosAnimo.setSelectionForeground(Color.WHITE);
        Pestañas.addTab("Estados de animo", new JScrollPane(EstadosAnimo));

        // =========================
        // 🟣 TAB 2: Publicaciones
        // =========================
        modeloPublicaciones = new DefaultTableModel(
                new Object[]{"ID", "Usuario", "Contenido", "Fecha", "Estado"}, 0);
        modeloPublicaciones.addRow(new Object[]{"P001", "Luis Gómez", "Hoy fue un buen día", "2025-10-18", "Visible"});
        modeloPublicaciones.addRow(new Object[]{"P002", "María López", "Necesito apoyo académico", "2025-10-17", "Visible"});

        Publicaciones = new JTable(modeloPublicaciones);
        Publicaciones.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        Publicaciones.setRowHeight(25);
        Publicaciones.setSelectionBackground(new Color(52, 152, 219));
        Publicaciones.setSelectionForeground(Color.WHITE);
        Pestañas.addTab("Publicaciones", new JScrollPane(Publicaciones));

        // =========================
        // 🟡 TAB 3: Usuarios Registrados
        // =========================
        modeloUsuarios = new DefaultTableModel(
                new Object[]{"ID", "Nombre", "Correo", "Rol", "Estado"}, 0);
        modeloUsuarios.addRow(new Object[]{"U001", "Juan Pérez", "juan@correo.com", "Usuario", "Activo"});
        modeloUsuarios.addRow(new Object[]{"U002", "Ana Torres", "ana@correo.com", "Usuario", "Activo"});
        modeloUsuarios.addRow(new Object[]{"U003", "Admin", "admin@studymind.com", "Administrador", "Activo"});

        Usuarios = new JTable(modeloUsuarios);
        Usuarios.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        Usuarios.setRowHeight(25);
        Usuarios.setSelectionBackground(new Color(52, 152, 219));
        Usuarios.setSelectionForeground(Color.WHITE);
        Pestañas.addTab("Usuarios Registrados", new JScrollPane(Usuarios));

        // =========================
        // 🔘 BOTONES
        // =========================
        btnActualizar = new JButton("Actualizar Datos");
btnActualizar.setFont(new Font("Segoe UI", Font.BOLD, 15));
btnActualizar.setBackground(new Color(0, 0, 0));
btnActualizar.setForeground(Color.WHITE);
btnActualizar.setFocusPainted(false);
btnActualizar.setBounds(150, 500, 180, 40);
add(btnActualizar);

btnCambiarEstado = new JButton("Cambiar Estado");
btnCambiarEstado.setFont(new Font("Segoe UI", Font.BOLD, 15));
btnCambiarEstado.setBackground(new Color(0, 0, 0));
btnCambiarEstado.setForeground(Color.WHITE);
btnCambiarEstado.setFocusPainted(false);
btnCambiarEstado.setBounds(380, 500, 180, 40);
add(btnCambiarEstado);

btnVolver = new JButton("Cerrar sesión");
btnVolver.setFont(new Font("Segoe UI", Font.BOLD, 15));
btnVolver.setBackground(new Color(0, 0, 0));
btnVolver.setForeground(Color.WHITE);
btnVolver.setFocusPainted(false);
btnVolver.setBounds(610, 500, 180, 40);
add(btnVolver);
        // =========================
        // ⚙️ ACCIONES
        // =========================
        btnActualizar.addActionListener(e -> {
            JTable tablaActual = getTablaSeleccionada();
            int fila = tablaActual.getSelectedRow();

            if (fila == -1) {
                JOptionPane.showMessageDialog(this,
                        "Selecciona una fila para actualizar o eliminar.",
                        "Aviso", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String id = tablaActual.getValueAt(fila, 0).toString();
            String tipo = Pestañas.getTitleAt(Pestañas.getSelectedIndex());

            int opcion = JOptionPane.showConfirmDialog(this,
                    "¿Deseas eliminar este registro?\n(ID: " + id + ")", "Confirmar",
                    JOptionPane.YES_NO_OPTION);

            if (opcion == JOptionPane.YES_OPTION) {
                ((DefaultTableModel) tablaActual.getModel()).removeRow(fila);
                JOptionPane.showMessageDialog(this, "Registro eliminado de " + tipo + ".");
            } else {
                JOptionPane.showMessageDialog(this, "Operación cancelada.");
            }
        });

        btnVolver.addActionListener(e -> {
            int option = JOptionPane.showConfirmDialog(this,
                    "¿Desea cerrar sesión?",
                    "Confirmar salida",
                    JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                new LoginView().setVisible(true);
                dispose();
            }
        });
        
        btnCambiarEstado.addActionListener(e -> {
    JTable tablaActual = getTablaSeleccionada();
    int fila = tablaActual.getSelectedRow();

    if (fila == -1) {
        JOptionPane.showMessageDialog(this,
                "Selecciona una fila para cambiar el estado.",
                "Aviso", JOptionPane.WARNING_MESSAGE);
        return;
    }

    DefaultTableModel modelo = (DefaultTableModel) tablaActual.getModel();
    int columnaEstado = -1;

    // Buscar la columna "Estado"
    for (int i = 0; i < modelo.getColumnCount(); i++) {
        if (modelo.getColumnName(i).equalsIgnoreCase("Estado")) {
            columnaEstado = i;
            break;
        }
    }

    if (columnaEstado == -1) {
        JOptionPane.showMessageDialog(this,
                "Esta tabla no tiene una columna 'Estado'.",
                "Aviso", JOptionPane.WARNING_MESSAGE);
        return;
    }

    String estadoActual = modelo.getValueAt(fila, columnaEstado).toString();
    String nuevoEstado;

    // Cambiar estado según el valor actual
    if (estadoActual.equalsIgnoreCase("Activo")) {
        nuevoEstado = "Inactivo";
    } else if (estadoActual.equalsIgnoreCase("Inactivo")) {
        nuevoEstado = "Activo";
    } else if (estadoActual.equalsIgnoreCase("Visible")) {
        nuevoEstado = "Oculto";
    } else if (estadoActual.equalsIgnoreCase("Oculto")) {
        nuevoEstado = "Visible";
    } else {
        nuevoEstado = "Pendiente";
    }

    modelo.setValueAt(nuevoEstado, fila, columnaEstado);

    JOptionPane.showMessageDialog(this,
            "El estado se cambió de '" + estadoActual + "' a '" + nuevoEstado + "'.",
            "Cambio realizado", JOptionPane.INFORMATION_MESSAGE);
});
    }

    private JTable getTablaSeleccionada() {
        int index = Pestañas.getSelectedIndex();
        switch (index) {
            case 0:
                return EstadosAnimo ;
            case 1:
                return Publicaciones;
            default:
                return Usuarios;
        }
    }



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        Pestañas = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        Publicaciones = new javax.swing.JTable();
        Publicacion = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        Usuarios = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        EstadosAnimo = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        btnVolver = new javax.swing.JButton();
        btnActualizar = new javax.swing.JButton();
        btnCambiarEstado = new javax.swing.JButton();

        jPanel4.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 241, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Publicaciones.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(Publicaciones);

        Publicacion.setText("Publicaciones");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(Publicacion)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(Publicacion)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(43, Short.MAX_VALUE))
        );

        Pestañas.addTab("Publicaciones", jPanel2);

        jLabel2.setText("Usuarios");

        Usuarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(Usuarios);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jLabel2))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(29, Short.MAX_VALUE))
        );

        Pestañas.addTab("UsuariosRegistrados", jPanel3);

        EstadosAnimo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(EstadosAnimo);

        jLabel1.setText("Estados de animo:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 452, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 19, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        Pestañas.addTab("Estados de Animo", jPanel1);

        btnVolver.setText("Volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        btnActualizar.setText("Actualizar datos");

        btnCambiarEstado.setText("Actualizar datos");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(289, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addComponent(btnVolver))
                            .addComponent(Pestañas, javax.swing.GroupLayout.PREFERRED_SIZE, 489, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(22, 22, 22))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnActualizar)
                        .addGap(169, 169, 169))))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(664, Short.MAX_VALUE)
                    .addComponent(btnCambiarEstado)
                    .addGap(22, 22, 22)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(btnVolver)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Pestañas, javax.swing.GroupLayout.PREFERRED_SIZE, 377, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addComponent(btnActualizar)
                .addGap(14, 14, 14))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(457, Short.MAX_VALUE)
                    .addComponent(btnCambiarEstado)
                    .addGap(16, 16, 16)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnVolverActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminMonitorView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminMonitorView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminMonitorView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminMonitorView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminMonitorView().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable EstadosAnimo;
    private javax.swing.JTabbedPane Pestañas;
    private javax.swing.JLabel Publicacion;
    private javax.swing.JTable Publicaciones;
    private javax.swing.JTable Usuarios;
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnCambiarEstado;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    // End of variables declaration//GEN-END:variables
}
