/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package modulos.usuario;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import modulos.BienestarEmocional.BienestarView;

/**
 *
 * @author WindowsPC
 */
public class RegistroView extends javax.swing.JPanel {

    /**
     * Creates new form RegistroView
     */
    public RegistroView() {
        initComponents();
        configurarPanelRegistro();
    }

    private void configurarPanelRegistro() {
      setLayout(null);
    setBackground(new Color(255, 255, 255));

    // --- Título principal ---
    JLabel lblTitulo = new JLabel("Registro de Usuario", JLabel.CENTER);
    lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 24));
    lblTitulo.setForeground(new Color(52, 73, 94));
    lblTitulo.setBounds(0, 20, 800, 40);
    add(lblTitulo);

    // --- Columna 1: Labels ---
    int labelX = 220;
    int fieldX = 380;
    int currentY = 80;
    int rowHeight = 60; // Espacio para campo + error

    // --- Campo nombre ---
    JLabel lblNombre = new JLabel("Nombre:*");
    lblNombre.setFont(new Font("Segoe UI", Font.PLAIN, 16));
    lblNombre.setBounds(labelX, currentY, 150, 25);
    add(lblNombre);

    txtNombre = new JTextField();
    txtNombre.setBounds(fieldX, currentY, 250, 30);
    add(txtNombre);

    lblErrorNombre = new JLabel(" ");
    lblErrorNombre.setFont(new Font("Segoe UI", Font.PLAIN, 12)); // Fuente más pequeña
    lblErrorNombre.setForeground(Color.RED);
    lblErrorNombre.setBounds(fieldX, currentY + 30, 250, 20);
    add(lblErrorNombre);

    currentY += rowHeight;

    // --- Campo apellido ---
    JLabel lblApellido = new JLabel("Apellido:*");
    lblApellido.setFont(new Font("Segoe UI", Font.PLAIN, 16));
    lblApellido.setBounds(labelX, currentY, 150, 25);
    add(lblApellido);

    txtApellido = new JTextField();
    txtApellido.setBounds(fieldX, currentY, 250, 30);
    add(txtApellido);

    lblErrorApellido = new JLabel(" ");
    lblErrorApellido.setFont(new Font("Segoe UI", Font.PLAIN, 12));
    lblErrorApellido.setForeground(Color.RED);
    lblErrorApellido.setBounds(fieldX, currentY + 30, 250, 20);
    add(lblErrorApellido);

    currentY += rowHeight;

    // --- Campo usuario ---
    JLabel lblUsuario = new JLabel("Usuario:*");
    lblUsuario.setFont(new Font("Segoe UI", Font.PLAIN, 16));
    lblUsuario.setBounds(labelX, currentY, 150, 25);
    add(lblUsuario);

    txtUsuario = new JTextField();
    txtUsuario.setBounds(fieldX, currentY, 250, 30);
    add(txtUsuario);

    lblErrorUsuario = new JLabel(" ");
    lblErrorUsuario.setFont(new Font("Segoe UI", Font.PLAIN, 12));
    lblErrorUsuario.setForeground(Color.RED);
    lblErrorUsuario.setBounds(fieldX, currentY + 30, 250, 20);
    add(lblErrorUsuario);

    currentY += rowHeight;

    // --- Campo correo ---
    JLabel lblCorreo = new JLabel("Correo:*");
    lblCorreo.setFont(new Font("Segoe UI", Font.PLAIN, 16));
    lblCorreo.setBounds(labelX, currentY, 150, 25);
    add(lblCorreo);

    txtCorreo = new JTextField();
    txtCorreo.setBounds(fieldX, currentY, 250, 30);
    add(txtCorreo);

    lblErrorCorreo = new JLabel(" ");
    lblErrorCorreo.setFont(new Font("Segoe UI", Font.PLAIN, 12));
    lblErrorCorreo.setForeground(Color.RED);
    lblErrorCorreo.setBounds(fieldX, currentY + 30, 250, 20);
    add(lblErrorCorreo);

    currentY += rowHeight;

    // --- Campo contraseña ---
    JLabel lblContraseña = new JLabel("Contraseña:*");
    lblContraseña.setFont(new Font("Segoe UI", Font.PLAIN, 16));
    lblContraseña.setBounds(labelX, currentY, 150, 25);
    add(lblContraseña);

    txtContraseña = new JPasswordField();
    txtContraseña.setBounds(fieldX, currentY, 250, 30);
    add(txtContraseña);

    // Botón para mostrar/ocultar contraseña
    

    lblErrorContraseña = new JLabel(" ");
    lblErrorContraseña.setFont(new Font("Segoe UI", Font.PLAIN, 12));
    lblErrorContraseña.setForeground(Color.RED);
    lblErrorContraseña.setBounds(fieldX, currentY + 30, 250, 20);
    add(lblErrorContraseña);

    currentY += rowHeight;

    // --- Confirmar contraseña ---
    JLabel lblComContraseña = new JLabel("Confirmar:*");
    lblComContraseña.setFont(new Font("Segoe UI", Font.PLAIN, 16));
    lblComContraseña.setBounds(labelX, currentY, 150, 25);
    add(lblComContraseña);

    txtComContraseña = new JPasswordField();
    txtComContraseña.setBounds(fieldX, currentY, 250, 30);
    add(txtComContraseña);

    // Botón para mostrar/ocultar confirmar contraseña
   

    lblErrorComContraseña = new JLabel(" ");
    lblErrorComContraseña.setFont(new Font("Segoe UI", Font.PLAIN, 12));
    lblErrorComContraseña.setForeground(Color.RED);
    lblErrorComContraseña.setBounds(fieldX, currentY + 30, 250, 20);
    add(lblErrorComContraseña);

    currentY += rowHeight;

    // --- Campo carrera (Opcional) ---
    JLabel lblCarrera = new JLabel("Carrera:");
    lblCarrera.setFont(new Font("Segoe UI", Font.PLAIN, 16));
    lblCarrera.setBounds(labelX, currentY, 150, 25);
    add(lblCarrera);

    txtCarrera = new JTextField();
    txtCarrera.setBounds(fieldX, currentY, 250, 30);
    add(txtCarrera);
    currentY += rowHeight;

    // --- Campo universidad (Opcional) ---
    JLabel lblUniversidad = new JLabel("Universidad:");
    lblUniversidad.setFont(new Font("Segoe UI", Font.PLAIN, 16));
    lblUniversidad.setBounds(labelX, currentY, 150, 25);
    add(lblUniversidad);

    txtUniversidad = new JTextField();
    txtUniversidad.setBounds(fieldX, currentY, 250, 30);
    add(txtUniversidad);

    currentY += rowHeight;

    // --- Información sobre el rol ---
    JLabel lblInfoRol = new JLabel("Nota: Todos los usuarios se registran con rol 'Usuario' por defecto");
    lblInfoRol.setFont(new Font("Segoe UI", Font.ITALIC, 12));
    lblInfoRol.setForeground(new Color(100, 100, 100));
    lblInfoRol.setBounds(labelX, currentY, 450, 20);
    add(lblInfoRol);

    currentY += 40;

    // --- Botones ---
    btnConfirmar = new JButton("Confirmar");
    btnConfirmar.setFont(new Font("Segoe UI", Font.BOLD, 15));
    btnConfirmar.setBackground(new Color(0, 0, 0));
    btnConfirmar.setForeground(Color.WHITE);
    btnConfirmar.setFocusPainted(false);
    btnConfirmar.setBounds(280, currentY, 120, 40);
    btnConfirmar.addActionListener(e -> validarRegistro());
    add(btnConfirmar);

    btnCancelar = new JButton("Cancelar");
    btnCancelar.setFont(new Font("Segoe UI", Font.BOLD, 15));
    btnCancelar.setBackground(new Color(0, 0, 0));
    btnCancelar.setForeground(Color.WHITE);
    btnCancelar.setFocusPainted(false);
    btnCancelar.setBounds(440, currentY, 120, 40);
    btnCancelar.addActionListener(e -> limpiarCampos());
    add(btnCancelar);

    btnVolver = new JButton("Volver");
    btnVolver.setFont(new Font("Segoe UI", Font.BOLD, 15));
    btnVolver.setBackground(new Color(0, 0, 0));
    btnVolver.setForeground(Color.WHITE);
    btnVolver.setFocusPainted(false);
    btnVolver.setBounds(600, currentY, 120, 40);
    btnVolver.addActionListener(e -> {
        JFrame ventanaPadre = (JFrame) SwingUtilities.getWindowAncestor(this);
        ventanaPadre.getContentPane().removeAll();
        ventanaPadre.getContentPane().add(new LoginView().getContentPane());
        ventanaPadre.revalidate();
        ventanaPadre.repaint();
    });
    add(btnVolver);

}



private void validarRegistro() {
    controlador.Registrar registrarUsuario = new controlador.Registrar();
    limpiarMensajes();
    boolean valido = true;

    // Validar nombre
    if (txtNombre.getText().trim().isEmpty()) {
        lblErrorNombre.setText("El nombre es obligatorio");
        valido = false;
    }

    // Validar apellido
    if (txtApellido.getText().trim().isEmpty()) {
        lblErrorApellido.setText("El apellido es obligatorio");
        valido = false;
    }

    // Validar usuario
    if (txtUsuario.getText().trim().isEmpty()) {
        lblErrorUsuario.setText("El usuario es obligatorio");
        valido = false;
    } else if (txtUsuario.getText().trim().length() < 3) {
        lblErrorUsuario.setText("Mínimo 3 caracteres");
        valido = false;
    }

    // Validar correo
    String email = txtCorreo.getText().trim();
    if (email.isEmpty()) {
        lblErrorCorreo.setText("El correo es obligatorio");
        valido = false;
    } else if (!validarFormatoEmail(email)) {
        lblErrorCorreo.setText("Formato de correo inválido");
        valido = false;
    }

    // Validar contraseña
    String password = new String(txtContraseña.getText());
    if (password.isEmpty()) {
        lblErrorContraseña.setText("La contraseña es obligatoria");
        valido = false;
    } else if (password.length() < 6) {
        lblErrorContraseña.setText("Mínimo 6 caracteres");
        valido = false;
    }

    // Validar confirmar contraseña
    String confirmPassword = new String(txtComContraseña.getText());
    if (confirmPassword.isEmpty()) {
        lblErrorComContraseña.setText("Confirme la contraseña");
        valido = false;
    } else if (!password.equals(confirmPassword)) {
        lblErrorComContraseña.setText("Las contraseñas no coinciden");
        valido = false;
    }

    // Carrera y Universidad son opcionales - NO mostramos error si están vacíos

    if (valido) {
        registrarUsuario.registrarUsuario(txtNombre, txtApellido, txtCorreo, txtUsuario, (JPasswordField) txtContraseña, txtCarrera, txtUniversidad);
    }
}

private void limpiarCampos() {
      
    txtNombre.setText("");
    txtApellido.setText("");
    txtUsuario.setText("");
    txtCorreo.setText("");
    txtContraseña.setText("");
    txtComContraseña.setText("");
    txtCarrera.setText("");
    txtUniversidad.setText("");
    
    limpiarMensajes();
    
    // Restaurar visibilidad de contraseñas
    if (btnMostrarContraseña != null) btnMostrarContraseña.setText("👁");
    if (btnMostrarComContraseña != null) btnMostrarComContraseña.setText("👁");
    
    txtNombre.requestFocus();
}

private void limpiarMensajes() {
    // Limpiar mensajes de error
     if (lblErrorNombre != null) lblErrorNombre.setText(" ");
    if (lblErrorApellido != null) lblErrorApellido.setText(" ");
    if (lblErrorUsuario != null) lblErrorUsuario.setText(" ");
    if (lblErrorCorreo != null) lblErrorCorreo.setText(" ");
    if (lblErrorContraseña != null) lblErrorContraseña.setText(" ");
    if (lblErrorComContraseña != null) lblErrorComContraseña.setText(" ");
}

private boolean validarFormatoEmail(String email) {
    String regex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$";
    return email.matches(regex);
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        txtCorreo = new javax.swing.JTextField();
        txtApellido = new javax.swing.JTextField();
        txtComContraseña = new javax.swing.JTextField();
        txtContraseña = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btnConfirmar = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        lblErrorComContraseña = new javax.swing.JLabel();
        lblErrorContraseña = new javax.swing.JLabel();
        lblErrorCorreo = new javax.swing.JLabel();
        lblErrorNombre = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        lblErrorApellido = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtUniversidad = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtCarrera = new javax.swing.JTextField();
        lblErrorUsuario = new javax.swing.JLabel();
        txtUsuario = new javax.swing.JTextField();
        lblUsuario = new javax.swing.JLabel();
        btnMostrarComContraseña = new javax.swing.JButton();
        btnMostrarContraseña = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        txtCorreo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCorreoActionPerformed(evt);
            }
        });

        jLabel1.setText("Ingrese un correo electronico");

        jLabel2.setText("Ingrese una contraseña");

        jLabel3.setText("ingrese su apellido");

        jLabel4.setText("Confirne su contraseña :");

        jLabel5.setText("REGISTRARSE");

        btnConfirmar.setText("confirmar");

        btnVolver.setText("volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        btnCancelar.setText(" cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        jLabel6.setText("ingrese su nombre:");

        jLabel7.setText("ingrese su carrera");

        jLabel8.setText("ingrese su carrera");

        lblUsuario.setText("ingrese un nombre de usuario");

        btnMostrarComContraseña.setText("confirmar");

        btnMostrarContraseña.setText("confirmar");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 425, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 10, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(lblErrorNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 417, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblUsuario))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(83, 83, 83)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtCarrera, javax.swing.GroupLayout.PREFERRED_SIZE, 420, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtUniversidad, javax.swing.GroupLayout.PREFERRED_SIZE, 420, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel6))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(205, 205, 205)
                        .addComponent(jLabel5))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblErrorContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 425, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtComContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 420, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(lblErrorComContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 412, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 422, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(btnConfirmar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnMostrarComContraseña)
                        .addGap(84, 84, 84)
                        .addComponent(btnCancelar)
                        .addGap(18, 18, 18)
                        .addComponent(btnVolver))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(65, 65, 65)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblErrorUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 417, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(txtUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 425, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, 420, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblErrorCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, 407, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblErrorApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 417, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 425, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(152, 152, 152)
                    .addComponent(btnMostrarContraseña)
                    .addContainerGap(319, Short.MAX_VALUE)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel5)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblErrorNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(81, 81, 81)
                        .addComponent(jLabel3)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblErrorApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(lblUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblErrorUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblErrorCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblErrorContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtComContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblErrorComContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtCarrera, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel8)
                .addGap(18, 18, 18)
                .addComponent(txtUniversidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(btnConfirmar, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(72, 72, 72))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnVolver)
                            .addComponent(btnCancelar)
                            .addComponent(btnMostrarComContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(84, 84, 84))))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                    .addContainerGap(738, Short.MAX_VALUE)
                    .addComponent(btnMostrarContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(44, 44, 44)))
        );

        jPanel3.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 241, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 546, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        // TODO add your handling code here:
        JFrame ventanaPadre = (JFrame) SwingUtilities.getWindowAncestor(this);
            ventanaPadre.getContentPane().removeAll();
            ventanaPadre.getContentPane().add(new LoginView().getContentPane());
            ventanaPadre.revalidate();
            ventanaPadre.repaint();
        
    }//GEN-LAST:event_btnVolverActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        // TODO add your handling code here:
        JFrame ventanaPadre = (JFrame) SwingUtilities.getWindowAncestor(this);
            ventanaPadre.getContentPane().removeAll();
            ventanaPadre.getContentPane().add(new BienestarView().getContentPane());
            ventanaPadre.revalidate();
            ventanaPadre.repaint();
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void txtCorreoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCorreoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCorreoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnConfirmar;
    private javax.swing.JButton btnMostrarComContraseña;
    private javax.swing.JButton btnMostrarContraseña;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel lblErrorApellido;
    private javax.swing.JLabel lblErrorComContraseña;
    private javax.swing.JLabel lblErrorContraseña;
    private javax.swing.JLabel lblErrorCorreo;
    private javax.swing.JLabel lblErrorNombre;
    private javax.swing.JLabel lblErrorUsuario;
    private javax.swing.JLabel lblUsuario;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtCarrera;
    private javax.swing.JTextField txtComContraseña;
    private javax.swing.JTextField txtContraseña;
    private javax.swing.JTextField txtCorreo;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtUniversidad;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables

    private void dispose() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
