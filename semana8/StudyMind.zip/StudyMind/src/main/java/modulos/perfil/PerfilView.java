/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package modulos.perfil;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import model.Usuario;
import vista.DashboardUsuarioView;

/**
 *
 * @author WindowsPC
 */
public class PerfilView extends javax.swing.JFrame {

    private Usuario usuarioLogueado;
private JTextField txtNombre;
private JTextField txtCorreo;
private JPasswordField txtContraseña;
private JButton btnMostrar;
private JButton btnVolver;

    /**
     * Creates new form PerfilView
     */
    public PerfilView() {
         initializeComponents();
        cargarDatosUsuario();
}


private void initializeComponents() {
    setTitle("Perfil de Usuario - StudyMind");
        setSize(900, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(new Color(245, 247, 250));

        // --- Título ---
        JLabel lblTitulo = new JLabel("Perfil del Usuario", JLabel.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblTitulo.setForeground(new Color(52, 73, 94));
        lblTitulo.setBounds(0, 30, 900, 40);
        add(lblTitulo);

        // --- Panel de información ---
        JPanel panelInfo = new JPanel();
        panelInfo.setLayout(null);
        panelInfo.setBackground(Color.WHITE);
        panelInfo.setBounds(100, 90, 700, 350);
        panelInfo.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        add(panelInfo);

        int yPos = 30;
        int labelX = 50;
        int fieldX = 200;

        // --- Campo Nombre ---
        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblNombre.setBounds(labelX, yPos, 120, 25);
        panelInfo.add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtNombre.setBounds(fieldX, yPos, 300, 30);
        txtNombre.setBackground(new Color(248, 249, 250));
        panelInfo.add(txtNombre);

        yPos += 50;

        // --- Campo Apellido ---
        JLabel lblApellido = new JLabel("Apellido:");
        lblApellido.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblApellido.setBounds(labelX, yPos, 120, 25);
        panelInfo.add(lblApellido);

        txtApellido = new JTextField();
        txtApellido.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtApellido.setBounds(fieldX, yPos, 300, 30);
        txtApellido.setBackground(new Color(248, 249, 250));
        panelInfo.add(txtApellido);

        yPos += 50;

        // --- Campo Correo ---
        JLabel lblCorreo = new JLabel("Correo Electrónico:");
        lblCorreo.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblCorreo.setBounds(labelX, yPos, 140, 25);
        panelInfo.add(lblCorreo);

        txtCorreo = new JTextField();
        txtCorreo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtCorreo.setBounds(fieldX, yPos, 300, 30);
        txtCorreo.setBackground(new Color(248, 249, 250));
        panelInfo.add(txtCorreo);

        yPos += 50;

        // --- Campo Usuario ---
        JLabel lblUsuario = new JLabel("Nombre de Usuario:");
        lblUsuario.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblUsuario.setBounds(labelX, yPos, 140, 25);
        panelInfo.add(lblUsuario);

        txtUsuario = new JTextField();
        txtUsuario.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtUsuario.setBounds(fieldX, yPos, 300, 30);
        txtUsuario.setBackground(new Color(248, 249, 250));
        panelInfo.add(txtUsuario);

        yPos += 50;

        // --- Campo Carrera ---
        JLabel lblCarrera = new JLabel("Carrera:");
        lblCarrera.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblCarrera.setBounds(labelX, yPos, 120, 25);
        panelInfo.add(lblCarrera);

        txtCarrera = new JTextField();
        txtCarrera.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtCarrera.setBounds(fieldX, yPos, 300, 30);
        txtCarrera.setBackground(new Color(248, 249, 250));
        panelInfo.add(txtCarrera);

        yPos += 50;

        // --- Campo Universidad ---
        JLabel lblUniversidad = new JLabel("Universidad:");
        lblUniversidad.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblUniversidad.setBounds(labelX, yPos, 120, 25);
        panelInfo.add(lblUniversidad);

        txtUniversidad = new JTextField();
        txtUniversidad.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtUniversidad.setBounds(fieldX, yPos, 300, 30);
        txtUniversidad.setBackground(new Color(248, 249, 250));
        panelInfo.add(txtUniversidad);

        // --- Sección de Contraseña (en un panel separado) ---
        JPanel panelContraseña = new JPanel();
        panelContraseña.setLayout(null);
        panelContraseña.setBackground(new Color(240, 245, 250));
        panelContraseña.setBounds(100, 460, 700, 80);
        panelContraseña.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            "Seguridad"
        ));
        add(panelContraseña);

        JLabel lblContraseña = new JLabel("Contraseña:");
        lblContraseña.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblContraseña.setBounds(50, 35, 120, 25);
        panelContraseña.add(lblContraseña);

        txtContraseña = new JPasswordField();
        txtContraseña.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtContraseña.setBounds(200, 35, 250, 30);
        txtContraseña.setBackground(new Color(248, 249, 250));
        txtContraseña.setEchoChar('•'); // Carácter para ocultar contraseña
        panelContraseña.add(txtContraseña);

        // --- Botón para mostrar/ocultar contraseña ---
        btnMostrarContraseña = new JButton("👁");
        btnMostrarContraseña.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btnMostrarContraseña.setBounds(455, 35, 40, 30);
        btnMostrarContraseña.setBackground(new Color(0, 0, 0));
        btnMostrarContraseña.setFocusPainted(false);
        btnMostrarContraseña.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnMostrarContraseña.setToolTipText("Mostrar contraseña");
        btnMostrarContraseña.addActionListener(e -> toggleContraseñaVisibility());
        panelContraseña.add(btnMostrarContraseña);

        // --- Botón Modificar ---
        btnModificar = new JButton("Guardar Cambios");
        btnModificar.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btnModificar.setBackground(new Color(0, 0, 0));
        btnModificar.setForeground(Color.WHITE);
        btnModificar.setFocusPainted(false);
        btnModificar.setBounds(250, 560, 150, 40);
        btnModificar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        add(btnModificar);

        // --- Botón Volver ---
        btnVolver = new JButton("Volver");
        btnVolver.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btnVolver.setBackground(new Color(0, 0, 0));
        btnVolver.setForeground(Color.WHITE);
        btnVolver.setFocusPainted(false);
        btnVolver.setBounds(420, 560, 180, 40);
        btnVolver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        add(btnVolver);

        // --- Acción del botón Modificar ---
        btnModificar.addActionListener(e -> {
            if (validarCampos()) {
                guardarCambios();
            }
        });

        // --- Acción del botón Volver ---
        btnVolver.addActionListener(e -> {
            new DashboardUsuarioView().setVisible(true);
            dispose();
        });
    }

    // Método para mostrar/ocultar contraseña
    private void toggleContraseñaVisibility() {
         if (txtContraseña.getEchoChar() == '•') {
        txtContraseña.setEchoChar((char) 0); // Mostrar
        btnMostrar.setText("🔒");
    } else {
        txtContraseña.setEchoChar('•'); // Ocultar
        btnMostrar.setText("👁");
    }
    txtContraseña.requestFocus();
    }

    // Método para cargar datos del usuario (simulados o reales)
    private void cargarDatosUsuario() {
        // Intentar obtener datos reales del usuario logueado
        Usuario usuarioLogueado = controlador.SesionUsuario.getUsuarioLogueado();
        
        if (usuarioLogueado != null) {
            // Cargar datos reales del usuario
            txtNombre.setText(usuarioLogueado.getNombre());
            txtApellido.setText(usuarioLogueado.getApellido());
            txtCorreo.setText(usuarioLogueado.getEmail());
            txtUsuario.setText(usuarioLogueado.getUsername());
            txtCarrera.setText(usuarioLogueado.getCarrera() != null ? usuarioLogueado.getCarrera() : "");
            txtUniversidad.setText(usuarioLogueado.getUniversidad() != null ? usuarioLogueado.getUniversidad() : "");
            txtContraseña.setText("contraseñaActual"); // En una app real, esto vendría de la BD
        } else {
            // Cargar datos de ejemplo si no hay usuario logueado
            cargarDatosEjemplo();
        }
        
        // Agregar tooltips para información adicional
        txtNombre.setToolTipText("Ingrese su nombre");
        txtApellido.setToolTipText("Ingrese su apellido");
        txtCorreo.setToolTipText("Ingrese su correo electrónico");
        txtUsuario.setToolTipText("Ingrese su nombre de usuario");
        txtCarrera.setToolTipText("Ingrese su carrera universitaria");
        txtUniversidad.setToolTipText("Ingrese su universidad");
        txtContraseña.setToolTipText("Ingrese su contraseña - Use el botón 👁 para mostrar/ocultar");
    }

    // Método para cargar datos de ejemplo
    private void cargarDatosEjemplo() {
        txtNombre.setText("Carlos");
        txtApellido.setText("Mendoza");
        txtCorreo.setText("carlos.m@mail.com");
        txtUsuario.setText("carlosm");
        txtCarrera.setText("Derecho");
        txtUniversidad.setText("Universidad Central");
        txtContraseña.setText("123456");
    }

    // Método para validar campos antes de guardar
    private boolean validarCampos() {
        String nombre = txtNombre.getText().trim();
        String apellido = txtApellido.getText().trim();
        String correo = txtCorreo.getText().trim();
        String usuario = txtUsuario.getText().trim();
        String contraseña = new String(txtContraseña.getPassword()).trim();

        if (nombre.isEmpty() || apellido.isEmpty() || correo.isEmpty() || 
            usuario.isEmpty() || contraseña.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Por favor, complete todos los campos obligatorios:\n" +
                    "• Nombre\n" +
                    "• Apellido\n" +
                    "• Correo electrónico\n" +
                    "• Nombre de usuario\n" +
                    "• Contraseña",
                    "Campos incompletos", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        // Validar formato de email
        if (!validarFormatoEmail(correo)) {
            JOptionPane.showMessageDialog(this,
                    "Por favor, ingrese un correo electrónico válido",
                    "Correo inválido", JOptionPane.WARNING_MESSAGE);
            txtCorreo.requestFocus();
            return false;
        }

        // Validar longitud de contraseña
        if (contraseña.length() < 6) {
            JOptionPane.showMessageDialog(this,
                    "La contraseña debe tener al menos 6 caracteres",
                    "Contraseña muy corta", JOptionPane.WARNING_MESSAGE);
            txtContraseña.requestFocus();
            return false;
        }

        return true;
    }

    // Método para validar formato de email
    private boolean validarFormatoEmail(String email) {
        String regex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$";
        return email.matches(regex);
    }

    // Método para guardar cambios en la base de datos
    private void guardarCambios() {
        try {
            // Obtener los datos actualizados
            String nombre = txtNombre.getText().trim();
            String apellido = txtApellido.getText().trim();
            String correo = txtCorreo.getText().trim();
            String usuario = txtUsuario.getText().trim();
            String carrera = txtCarrera.getText().trim();
            String universidad = txtUniversidad.getText().trim();
            String contraseña = new String(txtContraseña.getPassword()).trim();

            // Aquí iría el código para actualizar en la base de datos
            // Por ahora, simulamos la actualización
            
            boolean exito = actualizarUsuarioEnBD(nombre, apellido, correo, usuario, carrera, universidad, contraseña);
            
            if (exito) {
                JOptionPane.showMessageDialog(this,
                        "¡Datos actualizados exitosamente!\n\n" +
                        "👤 Nombre: " + nombre + " " + apellido + "\n" +
                        "📧 Correo: " + correo + "\n" +
                        "🔐 Usuario: " + usuario + "\n" +
                        "🎓 Carrera: " + (carrera.isEmpty() ? "No especificada" : carrera) + "\n" +
                        "🏫 Universidad: " + (universidad.isEmpty() ? "No especificada" : universidad),
                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this,
                        "Error al actualizar los datos en la base de datos",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error al guardar los cambios: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Método para actualizar usuario en la base de datos (simulado)
    private boolean actualizarUsuarioEnBD(String nombre, String apellido, String correo, 
                                         String usuario, String carrera, String universidad, 
                                         String contraseña) {
        // Simulación de actualización en base de datos
        // En una aplicación real, aquí iría el código SQL
        
        try {
            // Simular delay de base de datos
            Thread.sleep(1000);
            
            // Aquí iría el código real para actualizar:
            /*
            Connection conn = DB.ConexionBD.getConnection();
            String sql = "UPDATE usuario SET nombre=?, apellido=?, email=?, username=?, carrera=?, universidad=?, password=? WHERE id_usuario=?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, nombre);
            // ... resto de parámetros
            int filasAfectadas = pstmt.executeUpdate();
            return filasAfectadas > 0;
            */
            
            return true; // Simular éxito
            
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtApellido = new javax.swing.JTextField();
        txtUsuario = new javax.swing.JTextField();
        txtCarrera = new javax.swing.JTextField();
        txtUniversidad = new javax.swing.JTextField();
        btnModificar = new javax.swing.JButton();
        btnMostrarContraseña = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("MI PERFIL");

        jLabel2.setText("Nombre:");

        jLabel3.setText("correo");

        jLabel4.setText("contraseña");

        txtApellido.setText("jTextField1");

        txtUsuario.setText("jTextField1");
        txtUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUsuarioActionPerformed(evt);
            }
        });

        txtCarrera.setText("jTextField1");
        txtCarrera.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCarreraActionPerformed(evt);
            }
        });

        txtUniversidad.setText("jTextField1");
        txtUniversidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUniversidadActionPerformed(evt);
            }
        });

        btnModificar.setText("jButton1");

        btnMostrarContraseña.setText("jButton1");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(161, 161, 161)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4))))
                .addContainerGap(178, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(0, 160, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtCarrera, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtUniversidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(0, 160, Short.MAX_VALUE)))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(0, 158, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(btnModificar)
                        .addComponent(btnMostrarContraseña))
                    .addGap(0, 158, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addContainerGap(78, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(txtUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(txtCarrera, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(txtUniversidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(btnModificar)
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(btnMostrarContraseña)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(65, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUsuarioActionPerformed

    private void txtCarreraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCarreraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCarreraActionPerformed

    private void txtUniversidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUniversidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUniversidadActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PerfilView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PerfilView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PerfilView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PerfilView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PerfilView().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnMostrarContraseña;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtCarrera;
    private javax.swing.JTextField txtUniversidad;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables
}
