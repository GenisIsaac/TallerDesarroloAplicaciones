/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package modulos.perfil;

import java.awt.Color;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import model.Usuario;

/**
 *
 * @author WindowsPC
 */
public class EditarPerfilView extends javax.swing.JFrame {
 private Usuario usuarioLogueado;
    private JTextField txtNombre;
    private JTextField txtApellido;
    private JTextField txtCorreo;
    private JTextField txtUsername;
    private JTextField txtCarrera;
    private JTextField txtUniversidad;
    private JPasswordField txtNuevaContraseña;
    private JPasswordField txtConfirmarContraseña;

    public EditarPerfilView(Usuario usuario) {
        this.usuarioLogueado = usuario;
        initializeComponents();
        cargarDatosUsuario();
    }

    private EditarPerfilView() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void initializeComponents() {
        setTitle("Editar Perfil - StudyMind");
        setSize(600, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(new Color(245, 247, 250));

        // Título
        JLabel lblTitulo = new JLabel("Editar Perfil", JLabel.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitulo.setForeground(new Color(52, 73, 94));
        lblTitulo.setBounds(0, 20, 600, 40);
        add(lblTitulo);

        // Panel de edición
        JPanel panelEdicion = new JPanel();
        panelEdicion.setLayout(null);
        panelEdicion.setBackground(Color.WHITE);
        panelEdicion.setBounds(50, 80, 500, 300);
        panelEdicion.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 1));
        add(panelEdicion);

        int yPos = 30;
        int labelX = 30;
        int fieldX = 150;

        // Nombre
        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblNombre.setBounds(labelX, yPos, 100, 25);
        panelEdicion.add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtNombre.setBounds(fieldX, yPos, 300, 25);
        panelEdicion.add(txtNombre);

        yPos += 40;

        // Apellido
        JLabel lblApellido = new JLabel("Apellido:");
        lblApellido.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblApellido.setBounds(labelX, yPos, 100, 25);
        panelEdicion.add(lblApellido);

        txtApellido = new JTextField();
        txtApellido.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtApellido.setBounds(fieldX, yPos, 300, 25);
        panelEdicion.add(txtApellido);

        yPos += 40;

        // Correo
        JLabel lblCorreo = new JLabel("Correo:");
        lblCorreo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblCorreo.setBounds(labelX, yPos, 100, 25);
        panelEdicion.add(lblCorreo);

        txtCorreo = new JTextField();
        txtCorreo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtCorreo.setBounds(fieldX, yPos, 300, 25);
        panelEdicion.add(txtCorreo);

        yPos += 40;

        // Nueva Contraseña
        JLabel lblNuevaContraseña = new JLabel("Nueva Contraseña:");
        lblNuevaContraseña.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblNuevaContraseña.setBounds(labelX, yPos, 120, 25);
        panelEdicion.add(lblNuevaContraseña);

        txtNuevaContraseña = new JPasswordField();
        txtNuevaContraseña.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtNuevaContraseña.setBounds(fieldX, yPos, 300, 25);
        panelEdicion.add(txtNuevaContraseña);

        yPos += 40;

        // Confirmar Contraseña
        JLabel lblConfirmarContraseña = new JLabel("Confirmar:");
        lblConfirmarContraseña.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblConfirmarContraseña.setBounds(labelX, yPos, 100, 25);
        panelEdicion.add(lblConfirmarContraseña);

        txtConfirmarContraseña = new JPasswordField();
        txtConfirmarContraseña.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtConfirmarContraseña.setBounds(fieldX, yPos, 300, 25);
        panelEdicion.add(txtConfirmarContraseña);

        // Botones
        JButton btnGuardar = new JButton("Guardar Cambios");
        btnGuardar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnGuardar.setBackground(new Color(46, 204, 113));
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setFocusPainted(false);
        btnGuardar.setBounds(150, 400, 150, 35);
        btnGuardar.addActionListener(e -> guardarCambios());
        add(btnGuardar);

        JButton btnCancelar = new JButton("Cancelar");
        btnCancelar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnCancelar.setBackground(new Color(231, 76, 60));
        btnCancelar.setForeground(Color.WHITE);
        btnCancelar.setFocusPainted(false);
        btnCancelar.setBounds(320, 400, 150, 35);
        btnCancelar.addActionListener(e -> {
            new PerfilView().setVisible(true);
            dispose();
        });
        add(btnCancelar);
    }

    private void cargarDatosUsuario() {
        if (usuarioLogueado != null) {
            txtNombre.setText(usuarioLogueado.getNombre());
            txtApellido.setText(usuarioLogueado.getApellido());
            txtCorreo.setText(usuarioLogueado.getEmail());
            // Los campos de contraseña se dejan vacíos intencionalmente
        }
    }

    private void guardarCambios() {
        // Validar y guardar cambios en la base de datos
        String nuevaContraseña = new String(txtNuevaContraseña.getPassword());
        String confirmarContraseña = new String(txtConfirmarContraseña.getPassword());
        
        if (!nuevaContraseña.isEmpty() && !nuevaContraseña.equals(confirmarContraseña)) {
            JOptionPane.showMessageDialog(this, "Las contraseñas no coinciden", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Aquí llamarías al controlador para actualizar los datos en la BD
        boolean exito = actualizarUsuarioEnBD();
        
        if (exito) {
            JOptionPane.showMessageDialog(this, "Perfil actualizado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            new PerfilView().setVisible(true);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Error al actualizar el perfil", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean actualizarUsuarioEnBD() {
        // Implementar la lógica para actualizar en la base de datos
        // Usar PreparedStatement para actualizar nombre, apellido, email, y contraseña si se proporcionó
        return true; // Cambiar por la lógica real
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EditarPerfilView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EditarPerfilView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EditarPerfilView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EditarPerfilView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EditarPerfilView().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
