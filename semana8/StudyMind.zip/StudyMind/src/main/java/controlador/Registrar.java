/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author WindowsPC
 */
public class Registrar {
    public void registrarUsuario(JTextField txtNombre, JTextField txtApellido, JTextField txtEmail, 
                            JTextField txtUsername, JPasswordField txtPassword, JTextField txtCarrera,
                            JTextField txtUniversidad) {
    
    Connection conn = null;
    PreparedStatement ps = null;
    PreparedStatement psVerificar = null;
    ResultSet rs = null;
    
    try {
        // Validaciones iniciales
        if (txtNombre.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingrese su nombre", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        if (txtApellido.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingrese su apellido", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        if (txtEmail.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingrese su email", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        if (txtUsername.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingrese su nombre de usuario", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        if (txtPassword.getPassword().length == 0) {
            JOptionPane.showMessageDialog(null, "Ingrese su contraseña", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        if (txtCarrera.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingrese su carrera", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        if (txtUniversidad.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingrese su universidad", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Validar formato de email
        if (!validarEmail(txtEmail.getText().trim())) {
            JOptionPane.showMessageDialog(null, "Formato de email inválido", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Validar longitud de contraseña
        if (txtPassword.getPassword().length < 6) {
            JOptionPane.showMessageDialog(null, "La contraseña debe tener al menos 6 caracteres", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Conexión a BD
        DB.ConexionBD base = new DB.ConexionBD();
        conn = base.getConexion();
        
        // Verificar si el username o email ya existen
        String consultaVerificar = "SELECT id_usuario FROM usuario WHERE username = ? OR email = ?";
        psVerificar = conn.prepareStatement(consultaVerificar);
        psVerificar.setString(1, txtUsername.getText().trim());
        psVerificar.setString(2, txtEmail.getText().trim());
        
        rs = psVerificar.executeQuery();
        
        if (rs.next()) {
            JOptionPane.showMessageDialog(null, 
                "El nombre de usuario o email ya están registrados", 
                "Error de registro", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Obtener el id_rol para "usuario" (siempre será usuario)
        int idRol = obtenerIdRol(conn, "usuario");
        if (idRol == -1) {
            JOptionPane.showMessageDialog(null, "Error: Rol usuario no encontrado en la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Consulta para insertar nuevo usuario - ROL SIEMPRE SERÁ USUARIO
        String consultaInsertar = "INSERT INTO usuario (nombre, apellido, email, username, password, carrera, universidad, id_rol) " +
                                 "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        ps = conn.prepareStatement(consultaInsertar);
        ps.setString(1, txtNombre.getText().trim());
        ps.setString(2, txtApellido.getText().trim());
        ps.setString(3, txtEmail.getText().trim());
        ps.setString(4, txtUsername.getText().trim());
        ps.setString(5, new String(txtPassword.getPassword())); // En texto plano por ahora
        ps.setString(6, txtCarrera.getText().trim());
        ps.setString(7, txtUniversidad.getText().trim());
        ps.setInt(8, idRol); // Siempre el id_rol correspondiente a "usuario"
        
        int filasAfectadas = ps.executeUpdate();
        
        if (filasAfectadas > 0) {
            JOptionPane.showMessageDialog(null, 
                "¡Usuario registrado exitosamente!\n\n" +
                "Nombre: " + txtNombre.getText() + " " + txtApellido.getText() + "\n" +
                "Usuario: " + txtUsername.getText() + "\n" +
                "Rol: Usuario\n\n" +
                "Ahora puedes iniciar sesión con tus credenciales.", 
                "Registro Exitoso", 
                JOptionPane.INFORMATION_MESSAGE);
            
            // Limpiar campos después del registro exitoso
            limpiarCampos(txtNombre, txtApellido, txtEmail, txtUsername, txtPassword, txtCarrera, txtUniversidad);
            
        } else {
            JOptionPane.showMessageDialog(null, 
                "Error al registrar el usuario", 
                "Error de registro", 
                JOptionPane.ERROR_MESSAGE);
        }
        
    } catch(SQLException e) {
        JOptionPane.showMessageDialog(null, 
            "Error de base de datos: " + e.getMessage(), 
            "Error", 
            JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    } finally {
        // Cerrar recursos
        try {
            if (rs != null) rs.close();
            if (psVerificar != null) psVerificar.close();
            if (ps != null) ps.close();
            if (conn != null) conn.close();
        } catch(SQLException ex) {
            ex.printStackTrace();
        }
    }
}

// Método auxiliar para obtener el id_rol según el nombre del rol
private int obtenerIdRol(Connection conn, String nombreRol) {
    PreparedStatement ps = null;
    ResultSet rs = null;
    
    try {
        String consulta = "SELECT id_rol FROM rol WHERE nombre_rol = ?";
        ps = conn.prepareStatement(consulta);
        ps.setString(1, nombreRol.toLowerCase());
        
        rs = ps.executeQuery();
        
        if (rs.next()) {
            return rs.getInt("id_rol");
        }
    } catch(SQLException e) {
        e.printStackTrace();
    } finally {
        try {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
        } catch(SQLException ex) {
            ex.printStackTrace();
        }
    }
    return -1; // Retorna -1 si no encuentra el rol
}

// Método para validar formato de email
private boolean validarEmail(String email) {
    String regex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$";
    return email.matches(regex);
}

// Método para limpiar los campos después del registro
private void limpiarCampos(JTextField txtNombre, JTextField txtApellido, JTextField txtEmail, 
                          JTextField txtUsername, JPasswordField txtPassword, JTextField txtCarrera,
                          JTextField txtUniversidad) {
    
    txtNombre.setText("");
    txtApellido.setText("");
    txtEmail.setText("");
    txtUsername.setText("");
    txtPassword.setText("");
    txtCarrera.setText("");
    txtUniversidad.setText("");
}
}
