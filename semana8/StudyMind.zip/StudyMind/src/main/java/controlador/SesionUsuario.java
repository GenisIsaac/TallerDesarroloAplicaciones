/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import model.Usuario;

/**
 *
 * @author WindowsPC
 */
public class SesionUsuario {
     private static Usuario usuarioLogueado;
    
    public static void setUsuarioLogueado(Usuario usuario) {
        usuarioLogueado = usuario;
    }
    
    // CORREGIDO: Este método debe retornar Usuario, no SesionUsuario
    public static Usuario getUsuarioLogueado() {
        return usuarioLogueado;
    }
    
    public static void cerrarSesion() {
        usuarioLogueado = null;
    }
    
    public static boolean hayUsuarioLogueado() {
        return usuarioLogueado != null;
    }
}
