package DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {
    // Configuración de la base de datos
    private static final String URL = "jdbc:mysql://localhost:3306/studymind_db";
    private static final String USUARIO = "root";
    private static final String PASSWORD = "root";  
    
    private static Connection conexion = null;
    
    /**
     * Constructor privado para evitar instanciación
     */
    public ConexionBD() {}
    
    /**
     * Obtiene la conexión a la base de datos
     * @return Connection objeto de conexión
     */
    public static Connection getConexion() {
        try {
            if (conexion == null || conexion.isClosed()) {
                // Cargar el driver de MySQL
                Class.forName("com.mysql.cj.jdbc.Driver");
                
                // Establecer la conexión
                conexion = DriverManager.getConnection(URL, USUARIO, PASSWORD);
                System.out.println("✓ Conexión exitosa a la base de datos StudyMind");
            }
        } catch (ClassNotFoundException e) {
            System.err.println("✗ Error: Driver de MySQL no encontrado");
            System.err.println("  Asegúrate de tener la dependencia en pom.xml");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("✗ Error al conectar con la base de datos");
            System.err.println("  Verifica que MySQL esté ejecutándose");
            System.err.println("  URL: " + URL);
            System.err.println("  Usuario: " + USUARIO);
            e.printStackTrace();
        }
        return conexion;
    }
    
    /**
     * Cierra la conexión a la base de datos
     */
    public static void cerrarConexion() {
        try {
            if (conexion != null && !conexion.isClosed()) {
                conexion.close();
                System.out.println("✓ Conexión cerrada correctamente");
            }
        } catch (SQLException e) {
            System.err.println("✗ Error al cerrar la conexión");
            e.printStackTrace();
        }
    }
    
    /**
     * Método para probar la conexión
     */
   
}