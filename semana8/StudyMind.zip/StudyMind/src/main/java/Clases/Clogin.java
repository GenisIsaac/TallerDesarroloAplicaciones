/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import com.mysql.cj.protocol.Resultset;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import modulos.AdminDetalles.AdminMonitorView;
import vista.DashboardUsuarioView;

/**
 *
 * @author WindowsPC
 */
public class Clogin {
   public void Validar(JTextField usuario, JPasswordField contraseña, JComboBox<String> rolComboBox) {
       Connection conn = null;
PreparedStatement ps = null;
ResultSet rs = null;

try {
    // Validaciones iniciales
    if (usuario.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(null, "Ingrese su usuario", "Advertencia", JOptionPane.WARNING_MESSAGE);
        return;
    }
    
    if (contraseña.getPassword().length == 0) {
        JOptionPane.showMessageDialog(null, "Ingrese su contraseña", "Advertencia", JOptionPane.WARNING_MESSAGE);
        return;
    }
    
    String rolSeleccionado = (String) rolComboBox.getSelectedItem();
    if ("Seleccionar rol".equals(rolSeleccionado)) {
        JOptionPane.showMessageDialog(null, "Seleccione un rol válido", "Advertencia", JOptionPane.WARNING_MESSAGE);
        return;
    }
    
    // Conexión a BD
    DB.ConexionBD base = new DB.ConexionBD();
    conn = base.getConexion();
    
    
    // Consulta para verificar credenciales
    String consulta = "SELECT u.*, r.nombre_rol FROM usuario u " +
                    "INNER JOIN rol r ON u.id_rol = r.id_rol " +
                    "WHERE u.username = ? AND u.password = ? AND r.nombre_rol = ? AND u.estado = 'activo'";
    
    ps = conn.prepareStatement(consulta);
    ps.setString(1, usuario.getText().trim());
    ps.setString(2, new String(contraseña.getPassword()));
    ps.setString(3, rolSeleccionado.toLowerCase());
    
    rs = ps.executeQuery();
    
    if (rs.next()) {
        // Login exitoso
        String nombre = rs.getString("nombre");
        String apellido = rs.getString("apellido");
        String rol = rs.getString("nombre_rol");
        
        JOptionPane.showMessageDialog(null, 
            "Bienvenido: " + nombre + " " + apellido, 
            "Login Exitoso", 
            JOptionPane.INFORMATION_MESSAGE);
        
        // Redirigir según rol - CORREGIDO
        if ("administrador".equals(rol)) {
            new AdminMonitorView().setVisible(true);
            // Cerrar ventana de login actual
            SwingUtilities.getWindowAncestor(usuario).dispose();
        } else if ("usuario".equals(rol)) {
            new DashboardUsuarioView().setVisible(true);
            // Cerrar ventana de login actual
            SwingUtilities.getWindowAncestor(usuario).dispose();
        } else {
            JOptionPane.showMessageDialog(null, "Rol no reconocido: " + rol, "Error", JOptionPane.ERROR_MESSAGE);
        }
        
    } else {
        JOptionPane.showMessageDialog(null, 
            "Credenciales incorrectas o usuario inactivo", 
            "Error de autenticación", 
            JOptionPane.ERROR_MESSAGE);
    }
    
} catch(SQLException e) {
    JOptionPane.showMessageDialog(null, 
        "Error de conexión: " + e.getMessage(), 
        "Error", 
        JOptionPane.ERROR_MESSAGE);
    e.printStackTrace();
} finally {
    // Cerrar recursos
    try {
        if (rs != null) rs.close();
        if (ps != null) ps.close();
        if (conn != null) conn.close();
    } catch(SQLException ex) {
        ex.printStackTrace();
    }
}}}

