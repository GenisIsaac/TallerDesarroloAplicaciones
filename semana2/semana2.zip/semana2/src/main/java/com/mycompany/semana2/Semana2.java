/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.semana2;

import semana2.Ejercicio1;

/**
 *
 * @author WindowsPC
 */
public class Semana2 {

    public static void main(String[] args) {
        Ejercicio1 pension =new Ejercicio1();
        pension.setVisible(true);
    }
}
