/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.semana3ejercicio2;

import vista.ejercicio2;

/**
 *
 * @author WindowsPC
 */
public class Semana3Ejercicio2 {

    public static void main(String[] args) {
         ejercicio2 pension =new ejercicio2();
        pension.setVisible(true);
    }
}
