/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio2aplicaciones;

import java.util.Scanner;

/**
 *
 * @author WindowsPC
 */
public class Ejercicio2Aplicaciones {
  private double montoTotal;
  
    public static void main(String[] args) {
        ejercicio2 pension =new ejercicio2();
        pension.setVisible(true);
    }
    }
}
