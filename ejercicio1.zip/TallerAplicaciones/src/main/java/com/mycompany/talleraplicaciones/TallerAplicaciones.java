/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.talleraplicaciones;

import java.util.Scanner;

/**
 *
 * @author WindowsPC
 */
public class TallerAplicaciones  {
    
    public TallerAplicaciones() {

    }
}
