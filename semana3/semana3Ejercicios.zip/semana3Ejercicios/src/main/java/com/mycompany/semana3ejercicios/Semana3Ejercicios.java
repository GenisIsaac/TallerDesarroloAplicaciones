/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.semana3ejercicios;

import vista.ejercicio1;

/**
 *
 * @author WindowsPC
 */
public class Semana3Ejercicios {

    public static void main(String[] args) {
         ejercicio1 pension =new ejercicio1();
        pension.setVisible(true);
    }
}
