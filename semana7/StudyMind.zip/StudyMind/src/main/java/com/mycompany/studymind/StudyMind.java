/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.studymind;

import javax.swing.SwingUtilities;
import modulos.usuario.LoginView;

/**
 *
 * @author WindowsPC
 */
public class StudyMind {

    public static void main(String[] args) {
   LoginView pension =new LoginView();
        pension.setVisible(true);

    }
}
