package dao;

import DB.ConexionBD;
import model.Tarea;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TareaDAO {
    
    /**
     * Registrar nueva tarea
     */
    public boolean registrarTarea(Tarea tarea) {
        String sql = "INSERT INTO tarea (id_grupo, titulo, descripcion, fecha_limite, tipo) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = ConexionBD.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, tarea.getIdGrupo());
            pstmt.setString(2, tarea.getTitulo());
            pstmt.setString(3, tarea.getDescripcion());
            pstmt.setTimestamp(4, new Timestamp(tarea.getFechaLimite().getTime()));
            pstmt.setString(5, tarea.getTipo());
            
            return pstmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al registrar tarea: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Obtener tareas por grupo
     */
    public List<Tarea> obtenerTareasPorGrupo(int idGrupo) {
        List<Tarea> tareas = new ArrayList<>();
        String sql = "SELECT * FROM tarea WHERE id_grupo = ? ORDER BY fecha_limite ASC";
        
        try (Connection conn = ConexionBD.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idGrupo);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                tareas.add(construirTarea(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error al obtener tareas: " + e.getMessage());
        }
        return tareas;
    }
    
    /**
     * Eliminar tarea
     */
    public boolean eliminarTarea(int idTarea) {
        String sql = "DELETE FROM tarea WHERE id_tarea = ?";
        
        try (Connection conn = ConexionBD.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idTarea);
            return pstmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al eliminar tarea: " + e.getMessage());
            return false;
        }
    }
    
    private Tarea construirTarea(ResultSet rs) throws SQLException {
        Tarea tarea = new Tarea();
        tarea.setIdTarea(rs.getInt("id_tarea"));
        tarea.setIdGrupo(rs.getInt("id_grupo"));
        tarea.setTitulo(rs.getString("titulo"));
        tarea.setDescripcion(rs.getString("descripcion"));
        tarea.setFechaLimite(rs.getTimestamp("fecha_limite"));
        tarea.setTipo(rs.getString("tipo"));
        return tarea;
    }
}